package com.example.estados

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
